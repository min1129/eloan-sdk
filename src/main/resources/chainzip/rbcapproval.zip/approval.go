// approval
package main

import (
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"strconv"
	"strings"
	"time"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/hyperledger/fabric/core/util"
)

const (
	//审批事项的RList名称
	CONST_RLIST_APPROVAL = "APPROVAL"

	CONST_DEFAULT_CHAINCODE_RBCCUSTOMER string = "rbccustomer" //rbccustomer,会员链码默认Id
	CONST_RBCCUSTOMER_QUERYONE          string = "queryOne"    //queryOne,查询单个会员的方法名
	CONST_RBCCUSTOMER_QUERYALL          string = "queryAll"    //queryAll,查询所有会员的方法名

	//审批事项类型
	CONST_APPROVAL_Type_VERSIONUP string = "1" //1:版本升级
	//事项投票类型
	CONST_APPROVAL_VETOTYPE_ONEVOTEVETO  string = "1" //1:一票否决
	CONST_APPROVAL_VETOTYPE_TWOTHIRDVOTE string = "2" //2:三分之二同意
	CONST_APPROVAL_VETOTYPE_HALFVOTE     string = "3" //3:半数同意
	//事项状态
	CONST_APPROVAL_SIGN_AGREE  string = "1" //1:同意
	CONST_APPROVAL_SIGN_REJECT string = "2" //2:不同意

	//事项状态
	CONST_APPROVAL_Status_IN  string = "1" //1:审批中
	CONST_APPROVAL_Status_ON  string = "2" //2:审批通过
	CONST_APPROVAL_Status_OFF string = "3" //3:审批不通过
)

//会员签名
type Sign struct {
	CustomerNo string `json:"CustomerNo"` //会员No
	Status     string `json:"Status"`     //是否同意(1:同意；2:不同意)
	Time       string `json:"Time"`       //签名时间
}

//审批事项
type Approval struct {
	Id        string  `json:"Id"`        //Id(主键)
	Name      string  `json:"Name"`      //审批事项
	Type      string  `json:"Type"`      //审批事项类型，判断执行哪个方法(1:版本升级)
	VetoType  string  `json:"VetoType"`  //事项投票类型，判断是否执行方法(1:一票否决型)
	Chaincode string  `json:"Chaincode"` //执行的智能合约
	Funtion   string  `json:"Funtion"`   //执行合约的方法
	Args      string  `json:"Args"`      //执行方法的参数
	Creater   string  `json:"Creater"`   //事项发起人CustomerNo
	Time      string  `json:"Time"`      //发起时间
	Status    string  `json:"Status"`    //事项状态
	Signs     []*Sign `json:"Signs"`     //会员签名
	Extend    string  `json:"Extend"`    //扩展属性
}

//Args由 bytestring,bytestring 组成的字符串
func (c *Approval) GetArgs() []string {
	byteArgs := strings.Split(c.Args, ",")
	args := []string{}
	for _, v := range byteArgs {
		bArg, _ := hex.DecodeString(v)
		args = append(args, string(bArg))
	}
	return args
}

type Customer struct {
	CustomerId       string `json:"customerId"`       //会员CustomerId
	CustomerNo       string `json:"customerNo"`       //会员customerNo
	CustomerSignCert string `json:"customerSignCert"` //会员公钥，用于会员验证
}

type CustomerRList struct {
	Rnum string      `json:"rnum"` //会员总数
	Cpno string      `json:"cpno"` //当前页数
	List []*Customer `json:"list"` //会员列表
}

//获取当前用户
func (t *ApprovalChaincode) getCurrentCustomer(stub shim.ChaincodeStubInterface) (*Customer, error) {
	cert, _ := stub.GetCallerCertificate()
	if len(cert) == 0 {
		return nil, errors.New("Current Customer is nil")
	}
	scert := hex.EncodeToString(cert)
	//查询rbccustomer的默认执行chaincodename
	controllername, _ := stub.GetController()
	byterbccustomername, err := stub.QueryChaincode(controllername, util.ToChaincodeArgs("getChainCodeName", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER))
	if err != nil {
		logger.Errorf("Failed to query %s default chaincode. Got error: %s", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER, err.Error())
		return nil, fmt.Errorf("Failed to query %s default chaincode. Got error: %s", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER, err.Error())
	}
	rbccustomername := string(byterbccustomername)
	rbccustomerArg := fmt.Sprintf(`{"customerSignCert":"%s"}`, scert)
	rbccustomerargs := []string{CONST_RBCCUSTOMER_QUERYONE, rbccustomerArg}
	byteCustomer, err := stub.QueryChaincode(rbccustomername, util.ArrayToChaincodeArgs(rbccustomerargs))
	if err != nil {
		logger.Errorf("Failed to query chaincode. Got error: %s", err.Error())
		return nil, fmt.Errorf("Failed to query chaincode. Got error: %s", err.Error())
	}

	logger.Infof("Current customer info %s", byteCustomer)

	cus := new(Customer)
	json.Unmarshal(byteCustomer, &cus)

	logger.Infof("Current customer info %v", cus)

	return cus, nil
}

//获取超级用户列表
func (t *ApprovalChaincode) getSupperCustomer(stub shim.ChaincodeStubInterface) ([]*Customer, error) {
	//查询rbccustomer的默认执行chaincodename
	controllername, _ := stub.GetController()
	byterbccustomername, err := stub.QueryChaincode(controllername, util.ToChaincodeArgs("getChainCodeName", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER))
	if err != nil {
		logger.Errorf("Failed to query %s default chaincode. Got error: %s", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER, err.Error())
		return nil, fmt.Errorf("Failed to query %s default chaincode. Got error: %s", CONST_DEFAULT_CHAINCODE_RBCCUSTOMER, err.Error())
	}
	rbccustomername := string(byterbccustomername)
	rbccustomerargs := []string{CONST_RBCCUSTOMER_QUERYALL, `{"customerType":"1","customerStatus":"1"}`}
	byteCustomers, err := stub.QueryChaincode(rbccustomername, util.ArrayToChaincodeArgs(rbccustomerargs))
	if err != nil {
		logger.Errorf("Failed to query chaincode. Got error: %s", err.Error())
		return nil, fmt.Errorf("Failed to query chaincode. Got error: %s", err.Error())
	}

	logger.Infof("super customer info %s", byteCustomers)

	cr := new(CustomerRList)
	json.Unmarshal(byteCustomers, &cr)
	cs := cr.List
	logger.Infof("super customer info %v", cr)

	return cs, nil
}

//[Id,Name,Type,VetoType,Chaincode,Funtion,Args,Time,Extend]
func (t *ApprovalChaincode) newApproval(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	if len(args) != 9 {
		return nil, errors.New("Incorrect number of arguments. Expecting 9")
	}
	stime := args[7]
	_, err := time.ParseInLocation(timeformat, stime, time.Local)
	if err != nil {
		return nil, err
	}
	c, err := t.getCurrentCustomer(stub)
	if err != nil {
		return nil, err
	}
	//判断approval是否存在
	approvalRlist := shim.NewRList(stub, CONST_RLIST_APPROVAL)
	index := approvalRlist.IndexOf(args[0])
	if index >= 0 {
		return nil, errors.New("approval already exists")
	}

	approval := new(Approval)
	approval.Id = args[0]
	approval.Name = args[1]
	approval.Type = args[2]
	approval.VetoType = args[3]
	approval.Chaincode = args[4]
	approval.Funtion = args[5]
	approval.Args = args[6]
	approval.Creater = c.CustomerNo
	approval.Time = stime

	cs, err := t.getSupperCustomer(stub)
	if err != nil {
		return nil, err
	}
	if len(cs) == 1 {
		//如果此用户是唯一的超级会员，设置approval.Status为1
		if cs[0].CustomerNo == c.CustomerNo || cs[0].CustomerId == c.CustomerId {
			approval.Status = CONST_APPROVAL_Status_ON
		} else {
			//唯一的超级会员id和当前会员id不一致，当前用户可能为超级管理员
			return nil, errors.New("超级会员只有一个，但不是此会员")
		}
	} else {
		approval.Status = CONST_APPROVAL_Status_IN
	}

	signs := make([]*Sign, 0)
	sign := new(Sign)
	sign.CustomerNo = c.CustomerNo
	sign.Status = CONST_APPROVAL_SIGN_AGREE
	sign.Time = stime
	signs = append(signs, sign)
	approval.Signs = signs

	approval.Extend = args[8]

	//插入并保存approval对象信息
	approvalRlist.AddId(approval.Id)
	approvalRlist.SaveState()

	approvalData, _ := json.Marshal(approval)
	err = stub.PutState("__IDX_"+approval.Id, approvalData)
	if err != nil {
		return nil, err
	}

	//如果审批状态为通过，则执行审批事项方法
	if approval.Status == CONST_APPROVAL_Status_ON {
		newargs := approval.GetArgs()
		if approval.Chaincode == "rbccontroller" {
			//执行rbccontroller的方法
			controllername, _ := stub.GetController()
			approvalargs := []string{approval.Funtion}
			approvalargs = append(approvalargs, newargs...)
			return stub.InvokeChaincode(controllername, util.ArrayToChaincodeArgs(approvalargs))
		} else {
			//执行其他chaincode的方法
			approvalargs := []string{approval.Funtion}
			approvalargs = append(approvalargs, newargs...)
			return stub.InvokeChaincode("rbcc:"+approval.Chaincode, util.ArrayToChaincodeArgs(approvalargs))
		}
	}

	return nil, nil
}

//[Id,Status,Time]
func (t *ApprovalChaincode) approval(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	if len(args) != 3 {
		return nil, errors.New("Incorrect number of arguments. Expecting 3")
	}
	id := args[0]
	status := args[1]
	stime := args[2]
	_, err := time.ParseInLocation(timeformat, stime, time.Local)
	if err != nil {
		return nil, err
	}
	c, err := t.getCurrentCustomer(stub)
	if err != nil {
		return nil, err
	}
	approvalData, err := stub.GetState("__IDX_" + id)
	if err != nil {
		return nil, err
	}
	approval := new(Approval)
	json.Unmarshal(approvalData, approval)
	//审批状态不是审批中，返回错误
	if approval.Status != CONST_APPROVAL_Status_IN {
		return nil, errors.New("this approval is not in approval.")
	}
	cs, err := t.getSupperCustomer(stub)
	if err != nil {
		return nil, err
	}

	//标记此用户是否为超级用户,false:不是超级用户；true:超级用户
	flag := false
	//判断用户是否为超级会员之一
	for _, v := range cs {
		if v.CustomerId == c.CustomerId || v.CustomerNo == c.CustomerNo {
			flag = true
			break
		}
	}
	if !flag {
		logger.Errorf("approval fail: user[%s] is not super user", c.CustomerNo)
		return nil, fmt.Errorf("approval fail: user[%s] is not super user", c.CustomerNo)
	}

	//记录同意的人数
	agreenum := 0
	//最大能同意的人数
	agreemax := 0
	for k, v := range approval.Signs {
		//如果有用户审批签名，则返回错误
		if v.CustomerNo == c.CustomerNo {
			return nil, fmt.Errorf("this customer:[%s] is already in sign lists", v.CustomerNo)
		}
		if approval.Signs[k].Status == CONST_APPROVAL_SIGN_AGREE {
			agreenum++
		}
	}
	//如果没有该用户的签名
	sign := new(Sign)
	sign.CustomerNo = c.CustomerNo
	sign.Status = status
	sign.Time = stime
	approval.Signs = append(approval.Signs, sign)
	if sign.Status == CONST_APPROVAL_SIGN_AGREE {
		agreenum++
	}
	//会员总人数
	supernum := len(cs)
	agreemax = agreenum + len(cs) - len(approval.Signs)

	if approval.VetoType == CONST_APPROVAL_VETOTYPE_ONEVOTEVETO {
		//一票否决类型
		if supernum <= agreenum {
			//同意人数大于等于会员总数，则审批通过
			approval.Status = CONST_APPROVAL_Status_ON
		} else if supernum > agreemax {
			//最大能同意人数小于会员总数，则审批不通过
			approval.Status = CONST_APPROVAL_Status_OFF
		}

	} else if approval.VetoType == CONST_APPROVAL_VETOTYPE_TWOTHIRDVOTE {
		//三分之二同意类型
		if supernum*2 <= agreenum*3 {
			//同意人数大于等于会员总数的2/3，则审批通过
			approval.Status = CONST_APPROVAL_Status_ON
		} else if supernum*2 > agreemax*3 {
			//最大能同意人数小于会员总数的2/3，则审批不通过
			approval.Status = CONST_APPROVAL_Status_OFF
		}
	} else if approval.VetoType == CONST_APPROVAL_VETOTYPE_HALFVOTE {
		//半数同意类型
		if supernum <= agreenum*2 {
			//同意人数大于等于会员总数的1/2，则审批通过
			approval.Status = CONST_APPROVAL_Status_ON
		} else if supernum > agreemax*2 {
			//最大能同意人数小于会员总数的1/2，则审批不通过
			approval.Status = CONST_APPROVAL_Status_OFF
		}
	}

	//更新审批事项信息
	approvalData, _ = json.Marshal(approval)
	err = stub.PutState("__IDX_"+approval.Id, approvalData)
	if err != nil {
		return nil, err
	}

	//如果审批状态为通过，则执行审批事项方法
	if approval.Status == CONST_APPROVAL_Status_ON {
		newargs := approval.GetArgs()
		if approval.Chaincode == "rbccontroller" {
			//执行rbccontroller的方法
			controllername, _ := stub.GetController()
			approvalargs := []string{approval.Funtion}
			approvalargs = append(approvalargs, newargs...)
			return stub.InvokeChaincode(controllername, util.ArrayToChaincodeArgs(approvalargs))
		} else {
			//执行其他chaincode的方法
			approvalargs := []string{approval.Funtion}
			approvalargs = append(approvalargs, newargs...)
			return stub.InvokeChaincode("rbcc:"+approval.Chaincode, util.ArrayToChaincodeArgs(approvalargs))
		}
	}

	return nil, nil
}

// 查询所有审批项目列表
// args:[pagenum]
// pagenum:页数，可以不传
func (t *ApprovalChaincode) getApprovals(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	var pagenum int64
	if len(args) == 0 {
		pagenum = 0
	} else {
		pagenum, _ = strconv.ParseInt(args[0], 10, 64)
	}
	approvalRlist := shim.NewRList(stub, CONST_RLIST_APPROVAL)
	approvals := make([]*Approval, 0)
	begin, end := pageRow(pagesize, pagenum, int64(approvalRlist.Size))
	for i := begin; i < end; i++ {
		id := approvalRlist.GetIdByIndex(approvalRlist.Size - int(i) - 1)
		approval := new(Approval)
		approvalData, err := stub.GetState("__IDX_" + id)
		if err != nil {
			return nil, err
		}
		json.Unmarshal(approvalData, approval)

		if approval.Args != "" {
			approval.Args = strings.Join(approval.GetArgs(), ",")
		}
		approvals = append(approvals, approval)
	}

	res, err := json.Marshal(approvals)
	if err != nil {
		return nil, err
	}

	return res, nil
}

// 根据Id查询审批项目
// args:[Id]
func (t *ApprovalChaincode) getApproval(stub shim.ChaincodeStubInterface, args []string) ([]byte, error) {
	if len(args) == 0 {
		return nil, errors.New("Incorrect number of arguments. Expecting >0")
	}
	approval := new(Approval)
	approvalData, err := stub.GetState("__IDX_" + args[0])
	if err != nil {
		return nil, err
	}
	json.Unmarshal(approvalData, approval)

	if approval.Args != "" {
		approval.Args = strings.Join(approval.GetArgs(), ",")
	}

	approvalData, err = json.Marshal(approval)
	if err != nil {
		return nil, err
	}

	return approvalData, nil
}

func pageRow(pagesize, pagenum, length int64) (int64, int64) {
	var begin, end int64
	if pagenum <= 0 {
		return 0, length
	}
	total := length/pagesize + 1
	if pagenum < total {
		begin = (pagenum - 1) * pagesize
		end = pagenum * pagesize
	} else if pagenum == total {
		begin = (pagenum - 1) * pagesize
		end = length
	} else {
		begin = 0
		end = 0
	}
	return begin, end
}
