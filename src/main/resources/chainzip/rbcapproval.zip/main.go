// main
package main

import (
	"fmt"

	"github.com/hyperledger/fabric/core/chaincode/shim"
	"github.com/op/go-logging"
)

const (
	pagesize   int64  = 10
	timeformat string = "2006-01-02 15:04:05"
)

var logger = logging.MustGetLogger("approval")

type ApprovalChaincode struct {
}

func (t *ApprovalChaincode) Init(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	return nil, nil
}

func (t *ApprovalChaincode) Invoke(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	if function == "newApproval" {
		return t.newApproval(stub, args)
	} else if function == "approval" {
		return t.approval(stub, args)
	}

	return nil, nil
}

func (t *ApprovalChaincode) Query(stub shim.ChaincodeStubInterface, function string, args []string) ([]byte, error) {
	if function == "getApprovals" {
		return t.getApprovals(stub, args)
	} else if function == "getApproval" {
		return t.getApproval(stub, args)
	}

	return nil, nil
}

func main() {
	err := shim.Start(new(ApprovalChaincode))
	if err != nil {
		fmt.Printf("Error starting chaincode: %s", err)
	}
}
