/*
Copyright DTCC 2016 All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

         http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package com.rongzer.chaincode.customer;


import net.sf.json.JSONObject;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hyperledger.java.shim.ChaincodeBase;
import org.hyperledger.java.shim.ChaincodeStub;

import com.rongzer.chaincode.entity.CustomerEntity;
import com.rongzer.chaincode.entity.PageList;
import com.rongzer.chaincode.entity.RList;
import com.rongzer.chaincode.utils.JSONUtil;
import com.rongzer.chaincode.utils.StringUtil;

public class RBCCustomer extends ChaincodeBase {     
	 private static Log log = LogFactory.getLog(RBCCustomer.class);
	 	
	/**
	 * 新增、修改动作
	 */
	@Override
	public String run(ChaincodeStub stub, String function, String[] args) {
		log.info("In run, function:"+function);
		String runResult = null;
		switch (function) {
		/*case "createTable":
			createTable(stub,tableName);*/
		case "register":
			runResult = register(stub, args);//注册会员
			return runResult;
		case "delete":
			runResult = delete(stub, args);//删除会员
			return runResult;			
		case "modify":
			runResult = modify(stub, args);//修改会员信息
			return runResult;
		case "modifyStatus":
			runResult = modifyStatus(stub, args);//会员状态变更
			return runResult;
		case "resetCert":
			runResult = resetCert(stub, args);//重置验证证书
			return runResult;
		}
		
		return null;
	}
		
	/**
	 * 注册会员
	 * @param stub
	 * @param args
	 * @return
	 * @throws Exception 
	 */
	private String register(ChaincodeStub stub, String[] args){
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}

		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		//会员ID
		String customerId = (String)jParam.get("customerId");
		if(StringUtil.isEmpty(customerId) 
				|| StringUtil.isEmpty(jParam.get("customerNo")) 
				|| StringUtil.isEmpty(jParam.get("customerName")) 
				|| StringUtil.isEmpty(jParam.get("customerSignCert")) 
			){
			return "{\"Error\":\"customer info is not enough\"}";
		}
		
		if (StringUtil.isNotEmpty(stub.getState("__IDX_"+customerId)) 
				|| StringUtil.isNotEmpty(stub.getState("__IDX_"+customerId))
			|| StringUtil.isNotEmpty(stub.getState("__IDX_"+customerId))
			)
		{
			return "{\"Error\":\"customer is exists\"}";
		}
		
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jParam);
		customerEntity.setCustomerStatus("1");
		//注册会员
		stub.putState(customerEntity.getCustomerId(), customerEntity.toJSON().toString());
		
		//数据索引
		stub.putState("__IDX_"+customerEntity.getCustomerId(), customerEntity.getCustomerId());
		stub.putState("__IDX_"+customerEntity.getCustomerNo(), customerEntity.getCustomerId());
		stub.putState("__IDX_"+customerEntity.getCustomerSignCert(), customerEntity.getCustomerId());

		//数据顺序列表
		RList rList = RList.getInstance(stub,"customer");
		rList.add(customerId);
		rList.saveState();
		
		//按role角色建表
		RList rListType = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType());
		RList rListTypeStatus = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType()+"_"+customerEntity.getCustomerStatus());

		rListType.add(customerId);
		rListTypeStatus.add(customerId);
		rListType.saveState();
		
		return "{\"Success\":\"customerId"+customerId+"\"}";
	}
	
	/**
	 * 修改会员信息
	 * @param stub
	 * @param args 
	 * @return
	 */
	private String modify(ChaincodeStub stub, String[] args) {
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		//会员ID
		String customerId = (String)jParam.get("customerId");
		if(StringUtil.isEmpty(customerId)){
			return "{\"Error\":\"customerId is not found\"}";
		}
		
		JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(customerId));
		if(jCustomer == null){
			return "{\"Error\":\"customer is not exist\"}";
		}
		
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jCustomer);
		stub.delState("__IDX_"+customerEntity.getCustomerNo());
		stub.delState("__IDX_"+customerEntity.getCustomerSignCert());

		customerEntity.merge(jParam);
		//注册会员
		stub.putState(customerEntity.getCustomerId(), customerEntity.toJSON().toString());
		
		//数据索引
		stub.putState("__IDX_"+customerEntity.getCustomerNo(), customerEntity.getCustomerId());
		stub.putState("__IDX_"+customerEntity.getCustomerSignCert(), customerEntity.getCustomerId());

		return "{\"Success\":\"customerId="+customerId+"\"}";
	}
	

	/**
	 * 修改会员信息
	 * @param stub
	 * @param args 
	 * @return
	 */
	private String delete(ChaincodeStub stub, String[] args) {
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		//会员ID
		String customerId = (String)jParam.get("customerId");
		if(StringUtil.isEmpty(customerId)){
			return "{\"Error\":\"customerId is not found\"}";
		}
		
		JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(customerId));
		if(jCustomer == null){
			return "{\"Error\":\"customer is not exist\"}";
		}
		
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jCustomer);
		stub.delState(customerEntity.getCustomerId());
		stub.delState("__IDX_"+customerEntity.getCustomerId());
		stub.delState("__IDX_"+customerEntity.getCustomerNo());
		stub.delState("__IDX_"+customerEntity.getCustomerSignCert());

		//数据顺序列表
		RList rList = RList.getInstance(stub,"customer");
		rList.remove(customerId);
		rList.saveState();
		
		//按role角色建表
		RList rListRole = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType());
		RList rListTypeStatus = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType()+"_"+customerEntity.getCustomerStatus());

		rListRole.remove(customerId);
		rListTypeStatus.remove(customerId);
		rListRole.saveState();

		return "{\"Success\":\"customerId="+customerId+"\"}";
	}
	
	
	/**
	 * 会员状态变更
	 * @param stub
	 * @param args
	 * @return
	 */
	private String modifyStatus(ChaincodeStub stub, String[] args) {
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		//会员ID
		String customerId = (String)jParam.get("customerId");
		if(StringUtil.isEmpty(customerId)){
			return "{\"Error\":\"customerId is not found\"}";
		}
		//获取会员状态
		String customerStatus = (String)jParam.get("customerStatus");
		if(StringUtil.isEmpty(customerId)){
			return "{\"Error\":\"The new customerStatus is not found\"}";
		}
		
		JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(customerId));
		if(jCustomer == null){
			return "{\"Error\":\"customer is not exist\"}";
		}

		
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jCustomer);
		
		RList rListTypeStatus = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType()+"_"+customerEntity.getCustomerStatus());
		rListTypeStatus.remove(customerEntity.getCustomerId());
		
		customerEntity.setCustomerStatus(customerStatus);
		
		rListTypeStatus = RList.getInstance(stub,"customer_"+customerEntity.getCustomerType()+"_"+customerStatus);
		rListTypeStatus.add(customerEntity.getCustomerId());
		
		//注册会员
		stub.putState(customerEntity.getCustomerId(), customerEntity.toJSON().toString());

		
		return "{\"Success\":\"customerId="+customerId+",customerStatus="+customerStatus+"\"}";
	}
	
	/**
	 * 重置验证证书
	 * @param stub
	 * @param args
	 * @return
	 */
	private String resetCert(ChaincodeStub stub, String[] args) {
		
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		//会员ID
		String customerId = (String)jParam.get("customerId");
		if(StringUtil.isEmpty(customerId)){
			return "{\"Error\":\"customerId is not found\"}";
		}
		//获取会员状态
		String customerSignCert = (String)jParam.get("customerSignCert");
		if(StringUtil.isEmpty(customerSignCert)){
			return "{\"Error\":\"The new customerSignCert is not found\"}";
		}
		
		JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(customerId));
		if(jCustomer == null){
			return "{\"Error\":\"customer is not exist\"}";
		}
		
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jCustomer);
		
		stub.delState("__IDX_"+customerEntity.getCustomerSignCert());

		customerEntity.setCustomerSignCert(customerSignCert);
		//注册会员
		stub.putState(customerEntity.getCustomerId(), customerEntity.toJSON().toString());
		stub.putState("__IDX_"+customerEntity.getCustomerSignCert(), customerEntity.getCustomerId());		
		
		return "{\"Success\":\"customerId="+customerId+",customerSignCert="+customerSignCert+"\"}";
	}

	
	/**
	 * 查询动作
	 */
	@Override
	public String query(ChaincodeStub stub, String function, String[] args) {
		log.info("In run, function:"+function);
		String queryResult = null;
		switch (function) {
		case "queryOne":
			queryResult = queryOne(stub, args);//根据用户ID获取用户详细
			return queryResult;
		case "queryAll":
			queryResult = queryAll(stub, args);//查询所有用户列表
			return queryResult;		
		}	
		
		return null;
	}
	
	/**
	 * 根据用户ID获取用户详细
	 * @param stub
	 * @param args
	 * @return
	 */
	private String queryOne(ChaincodeStub stub, String[] args) {
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		
		//获取会员ID
		String queryKey = (String)jParam.get("customerId");
		if (StringUtil.isEmpty(queryKey)){
			queryKey = (String)jParam.get("customerNo");
		}
		if (StringUtil.isEmpty(queryKey)){
			queryKey = (String)jParam.get("customerSignCert");
		}
		
		if (StringUtil.isEmpty(queryKey)){
			return "{\"Error\":\"Incorrect query args\"}";
		}
		//查询索引
		queryKey = stub.getState("__IDX_"+queryKey);
		if (StringUtil.isEmpty(queryKey)){
			return "{\"Error\":\"customer is not exist\"}";
		}
		
		JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(queryKey));
		if(jCustomer == null){
			return "{\"Error\":\"customer is not exist\"}";
		}
		//初始化Customer对象
		CustomerEntity customerEntity = new CustomerEntity(jCustomer);
		
		return customerEntity.toJSON().toString();
	}
	
	/**
	 * 查询所有用户列表,倒序
	 * @param stub
	 * @param args
	 * @return
	 */
	private String queryAll(ChaincodeStub stub, String[] args) {
		if (args.length != 1 ) {
			return "{\"Error\":\"Incorrect number of arguments. Expecting 1\"}";
		}
		//获取参数，转移成map[string]string
		String argString = (String) args[0];
		JSONObject jParam = JSONUtil.getJSONObjectFromStr(argString);
		int cpno = StringUtil.toInt(jParam.get("cpno"), 0);
		
		String rListKey = "customer";
		//获取会员类型
		String customerType = (String)jParam.get("customerType");
		//获取会员状态
		String customerStatus = (String)jParam.get("customerStatus");
		
		if (StringUtil.isNotEmpty(customerType))
		{
			rListKey = "customer_"+customerType;
			if (StringUtil.isNotEmpty(customerStatus))
			{
				rListKey +="_"+customerStatus;
			}
		}
		//数据顺序列表
		RList rList = RList.getInstance(stub,rListKey);
		int start = cpno*PageList.PAGE_ROW;
		int end = (cpno+1) * PageList.PAGE_ROW ;
		if (end >rList.size())
		{
			end = rList.size();
		}
		PageList<CustomerEntity> lisCustomer = new PageList<CustomerEntity>();
		lisCustomer.setRnum(rList.size());
		lisCustomer.setCpno(cpno);
		
		int nSize = rList.size();

		for (int i=start;i<end;i++)
		{
			JSONObject jCustomer = (JSONObject)JSONUtil.getJSONObjectFromStr(stub.getState(rList.get(nSize - i - 1)));

			CustomerEntity customerEntity = new CustomerEntity(jCustomer);
			lisCustomer.add(customerEntity);
		}
				
		return lisCustomer.toJSON().toString();
	}
	
	@Override
	public String getChaincodeID() {
		return "RBCCustomer";
	}
	
	public static void main(String[] args) throws Exception {
		new RBCCustomer().start(args);
	}
}
